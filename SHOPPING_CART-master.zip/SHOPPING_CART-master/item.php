<?php 
class Item{
 var $id;
 var $name;
 var $price;
 var $quantity;
}
 ?>